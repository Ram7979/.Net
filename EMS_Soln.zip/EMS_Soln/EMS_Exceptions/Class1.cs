﻿using System;

namespace EMS_Exceptions
{
    public class Class1
    {
    }
}
