﻿using System;

namespace EMS_DAL
{
    public class Class1
    {
    }
}
