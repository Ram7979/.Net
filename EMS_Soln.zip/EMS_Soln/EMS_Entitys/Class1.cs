﻿using System;

namespace EMS_Entitys
{
    public class Class1
    {
    }
}
