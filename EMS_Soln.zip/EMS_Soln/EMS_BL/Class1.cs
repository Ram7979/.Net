﻿using System;

namespace EMS_BL
{
    public class Class1
    {
    }
}
